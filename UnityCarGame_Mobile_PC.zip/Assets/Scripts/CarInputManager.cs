
using UnityEngine;

public class CarInputManager : MonoBehaviour
{
    public static float steeringInput;
    public static float accelerationInput;
    public static bool brakePressed;

    public bool isMobile = false;
    public Joystick joystick;
    public ButtonInput brakeButton;
    public ButtonInput gasButton;

    void Update()
    {
#if UNITY_ANDROID || UNITY_IOS
        isMobile = true;
#else
        isMobile = false;
#endif

        if (isMobile)
        {
            steeringInput = joystick.Horizontal;
            accelerationInput = gasButton.isPressed ? 1f : 0f;
            brakePressed = brakeButton.isPressed;
        }
        else
        {
            steeringInput = Input.GetAxis("Horizontal");
            accelerationInput = Input.GetAxis("Vertical");
            brakePressed = Input.GetKey(KeyCode.Space);
        }
    }
}
