
using UnityEngine;

public class CarController : MonoBehaviour
{
    public float maxSpeed = 20f;
    public float turnSpeed = 5f;
    public float brakeForce = 3000f;

    private Rigidbody rb;
    private float steeringInput, accelerationInput, brakeInput;

    void Start() { rb = GetComponent<Rigidbody>(); }
    void Update() { GetInput(); }
    void FixedUpdate() { Move(); }

    void GetInput() {
        steeringInput = CarInputManager.steeringInput;
        accelerationInput = CarInputManager.accelerationInput;
        brakeInput = CarInputManager.brakePressed ? brakeForce : 0f;
    }

    void Move() {
        rb.AddForce(transform.forward * accelerationInput * maxSpeed, ForceMode.Acceleration);
        rb.AddTorque(0, steeringInput * turnSpeed, 0);
        if (brakeInput > 0) rb.drag = 5f; else rb.drag = 0f;
    }
}
